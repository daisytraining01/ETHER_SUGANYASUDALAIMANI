package maveric.exam.com;

public class classPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String realString = "ABA";
		StringBuilder str1 = new StringBuilder(realString);
		//System.out.println(str1);
		str1.reverse();
		//System.out.println(strval);
		System.out.println(realString);
		//System.out.println(strval);
		
		if(realString.equals(str1.toString()))
			System.out.println("palindrome");
		else
			System.out.println("not palindrome");
		
	//	String oneString = str1.toString();
		//String revString = strval.toString();
		
		//System.out.println(oneString);
		//System.out.println(revString);
		
		
		
		/*
		 * if(revString.equals(oneString)) System.out.println("test"); else
		 * System.out.println("bad");
		 */		
		//Boolean result = strval.equals(strval.reverse());
		/*
		 * System.out.println(result); System.out.println(str1);
		 * System.out.println(strval);
		 */
		/*
		 * if(result == true) System.out.println("It is palindrome"); else
		 * System.out.println("It is not palindrome");
		 */
		
	}

}


/*OUTPUT
ABA
palindrome*/