package maveric.exam.com;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class classFileReading {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String fileName = "File/readingfile";
		ArrayList<String> s =new ArrayList<String>();
		File file = new File(fileName);
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String line;
		int n=0;
		while((line = br.readLine()) != null){
		    //process the line
			s.add(line);
		   // System.out.println(line);
		    n++;
		}
		System.out.println("---------------------");
		for(int j=0;j<s.size();j=j+2)
		{
			System.out.println(s.get(j));
		}
		
	}

}


/*
 * OUTPUT:
 * 
 * ---------------------
 *  test
 *  app 
 *  java
 */

/*FILE Content
 
test
testing
app
application
java
very bad

*/