package maveric.exam.com;

interface InterFAceTrail{
	public void add(int a,int b);
	public void add(int a,double b);
}

public class classOverload implements InterFAceTrail{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		classOverload obj=new classOverload();
		int a=8;
		int b=10;
		double c = 3.2;
		//obj.add(a, b); // this calls the first add function
		obj.add(a, c); // this calls the second add function
		
		
	}
	public void add(int a,int b)
	{
		System.out.println(a+b);
	}
	
	public void add(int a,double b) {
		System.out.println(a+b);
	}
}


/*
 * OUTPUT
 * 
 * 11.2
 */