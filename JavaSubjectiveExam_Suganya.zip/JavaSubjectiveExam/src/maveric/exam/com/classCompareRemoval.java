package maveric.exam.com;

public class classCompareRemoval {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Comparing 2 Strings\n");
		String str1 = "Ether";
		String str2 = "Ether";
		
		if(str1.equals(str2))
			System.out.println(str1+" is same as "+str2);
		
		System.out.println("==========================================\nRemoving the 2(ST) letter from REST ASSURED\n");
		
		String orgString = "REST ASSURED";
		System.out.println(orgString.replace("ST", ""));
	}

}

/*OUTPUT

Comparing 2 Strings

Ether is same as Ether
==========================================
Removing the 2(ST) letter from REST ASSURED

RE ASSURED
*/
